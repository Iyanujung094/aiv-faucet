import json
import os
import secrets
import base64
import time
from web3 import Web3
import requests
from colorama import init, Fore
from dotenv import load_dotenv
from pyfiglet import Figlet
from datetime import datetime

init()
load_dotenv()

ADDRESS_PENERIMA = os.getenv('ADDRESS_PENERIMA')
JUMLAH_TX_FEE = float(os.getenv('JUMLAH_TX_FEE', 0.000006))
PK_PENGIRIM = os.getenv('PK_PENGIRIM')

rpc_url = "https://sepolia-rollup.arbitrum.io/rpc"
chain_id = 421614
aiv_contract_address = "0x78741720bf7ae1b9406421AeA2FC2Ce9F44d3858"

erc20_abi = [
    {
        "constant": True,
        "inputs": [{"name": "_owner", "type": "address"}],
        "name": "balanceOf",
        "outputs": [{"name": "balance", "type": "uint256"}],
        "type": "function"
    },
    {
        "constant": False,
        "inputs": [
            {"name": "_to", "type": "address"},
            {"name": "_value", "type": "uint256"}
        ],
        "name": "transfer",
        "outputs": [{"name": "success", "type": "bool"}],
        "type": "function"
    }
]

def generate_fake_jwt():
    header = {"alg": "HS256", "typ": "JWT"}
    payload = {
        "iss": "supabase",
        "ref": "jpvvaetqdxhezxuuwpcw",
        "role": "anon",
        "iat": int(time.time()),
        "exp": int(time.time()) + 315360000
    }
    header_b64 = base64.urlsafe_b64encode(json.dumps(header).encode()).decode().rstrip("=")
    payload_b64 = base64.urlsafe_b64encode(json.dumps(payload).encode()).decode().rstrip("=")
    signature = base64.urlsafe_b64encode(secrets.token_bytes(32)).decode().rstrip("=")
    return f"{header_b64}.{payload_b64}.{signature}"

def claim_faucet():
    fake_apikey = generate_fake_jwt()
    fake_auth = f"Bearer {generate_fake_jwt()}"

    url = "https://jpvvaetqdxhezxuuwpcw.supabase.co/functions/v1/faucet-claim"

    headers = {
        "accept": "*/*",
        "accept-encoding": "gzip, deflate, br, zstd",
        "accept-language": "ja,en-US;q=0.9,en;q=0.8",
        "apikey": fake_apikey,
        "authorization": fake_auth,
        "content-type": "application/json",
        "origin": "https://aivoraprotocol.xyz",
        "referer": "https://aivoraprotocol.xyz/",
        "sec-ch-ua": '"Not;A=Brand";v="99", "Microsoft Edge";v="139", "Chromium";v="139"',
        "sec-ch-ua-mobile": "?0",
        "sec-ch-ua-platform": '"Windows"',
        "sec-fetch-dest": "empty",
        "sec-fetch-mode": "cors",
        "sec-fetch-site": "cross-site",
        "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36 Edg/139.0.0.0",
        "x-client-info": "supabase-js-web/2.56.1"
    }

    while True:
        try:
            w3 = Web3()
            account = w3.eth.account.create()
            address = account.address
            private_key = account._private_key.hex()

            payload = {"walletAddress": address}

            print(f"{Fore.YELLOW}Sending request for address: {address}{Fore.RESET}")
            response = requests.post(url, headers=headers, json=payload)

            if response.status_code == 200:
                wallets_file = 'wallets.json'
                if os.path.exists(wallets_file):
                    with open(wallets_file, 'r') as f:
                        wallets = json.load(f)
                else:
                    wallets = []

                wallets.append({"address": address, "private_key": private_key})

                with open(wallets_file, 'w') as f:
                    json.dump(wallets, f, indent=4)

                print(f"{Fore.GREEN}Success: Wallet saved: {address}{Fore.RESET}")
            else:
                print(f"{Fore.RED}Failed: Status {response.status_code}: {response.text}{Fore.RESET}")

            time.sleep(0.1)

        except KeyboardInterrupt:
            print(f"{Fore.YELLOW}Stopped by user{Fore.RESET}")
            break
        except Exception as e:
            print(f"{Fore.RED}Error: {str(e)}{Fore.RESET}")
            time.sleep(0.1)

def send_fee():
    if not PK_PENGIRIM:
        print(f"{Fore.RED}PK_PENGIRIM not found in .env{Fore.RESET}")
        exit()

    transfer_amount = Web3.to_wei(JUMLAH_TX_FEE, 'ether')
    w3 = Web3(Web3.HTTPProvider(rpc_url))

    if not w3.is_connected():
        print(f"{Fore.RED}Failed to connect to RPC{Fore.RESET}")
        exit()

    wallets_file = 'wallets.json'
    if not os.path.exists(wallets_file):
        print(f"{Fore.RED}File wallets.json not found{Fore.RESET}")
        exit()

    with open(wallets_file, 'r') as f:
        wallets = json.load(f)

    try:
        sender_account = w3.eth.account.from_key(PK_PENGIRIM)
        sender_address = sender_account.address
    except:
        print(f"{Fore.RED}Invalid private key{Fore.RESET}")
        exit()

    sender_balance = w3.eth.get_balance(sender_address)
    required_total = transfer_amount * len(wallets) + Web3.to_wei(0.001, 'ether')
    if sender_balance < required_total:
        print(f"{Fore.RED}Sender balance insufficient. Need at least {Web3.from_wei(required_total, 'ether')} ETH{Fore.RESET}")
        exit()

    for wallet in wallets:
        recipient_address = wallet['address']
        print(f"{Fore.YELLOW}Processing transfer to: {recipient_address}{Fore.RESET}")
        try:
            checksum_recipient = w3.to_checksum_address(recipient_address)
            nonce = w3.eth.get_transaction_count(sender_address)
            tx = {
                'chainId': chain_id,
                'to': checksum_recipient,
                'value': transfer_amount,
                'gas': 25000,
                'gasPrice': w3.to_wei('1', 'gwei'),
                'nonce': nonce,
            }
            signed_tx = w3.eth.account.sign_transaction(tx, private_key=PK_PENGIRIM)
            tx_hash = w3.eth.send_raw_transaction(signed_tx.raw_transaction)
            print(f"{Fore.GREEN}Tx sent: {tx_hash.hex()}{Fore.RESET}")
            w3.eth.wait_for_transaction_receipt(tx_hash)
            print(f"{Fore.GREEN}Success: Transferred to {recipient_address}{Fore.RESET}")
            time.sleep(2)
        except Exception as e:
            print(f"{Fore.RED}Error: {str(e)}{Fore.RESET}")

def transfer_faucet():
    w3 = Web3(Web3.HTTPProvider(rpc_url))

    if not w3.is_connected():
        print(f"{Fore.RED}Failed to connect to RPC{Fore.RESET}")
        exit()

    wallets_file = 'wallets.json'
    if not os.path.exists(wallets_file):
        print(f"{Fore.RED}File wallets.json not found{Fore.RESET}")
        exit()

    with open(wallets_file, 'r') as f:
        wallets = json.load(f)

    if not w3.is_address(ADDRESS_PENERIMA):
        print(f"{Fore.RED}Invalid destination address{Fore.RESET}")
        exit()

    destination_address = w3.to_checksum_address(ADDRESS_PENERIMA)
    aiv_contract = w3.eth.contract(address=w3.to_checksum_address(aiv_contract_address), abi=erc20_abi)

    for wallet in wallets:
        address = wallet['address']
        private_key = wallet['private_key']
        print(f"{Fore.YELLOW}Processing: {address}{Fore.RESET}")
        try:
            checksum_address = w3.to_checksum_address(address)
            eth_balance = w3.eth.get_balance(checksum_address)
            if eth_balance < w3.to_wei(0.000006, 'ether'):
                print(f"{Fore.YELLOW}ETH low (<0.000006), skipping: {address}{Fore.RESET}")
                continue
            aiv_balance = aiv_contract.functions.balanceOf(checksum_address).call()
            if aiv_balance == 0:
                print(f"{Fore.YELLOW}AIV 0, skipping: {address}{Fore.RESET}")
                continue
            print(f"{Fore.YELLOW}AIV balance: {w3.from_wei(aiv_balance, 'ether')} - Sending to {destination_address}{Fore.RESET}")
            retries = 0
            max_retries = 3
            while retries < max_retries:
                try:
                    nonce = w3.eth.get_transaction_count(checksum_address)
                    tx = aiv_contract.functions.transfer(destination_address, aiv_balance).build_transaction({
                        'chainId': chain_id,
                        'gas': 60000,
                        'gasPrice': w3.to_wei('0.1', 'gwei'),
                        'nonce': nonce,
                    })
                    signed_tx = w3.eth.account.sign_transaction(tx, private_key=private_key)
                    tx_hash = w3.eth.send_raw_transaction(signed_tx.raw_transaction)
                    print(f"{Fore.GREEN}Tx sent: {tx_hash.hex()}{Fore.RESET}")
                    w3.eth.wait_for_transaction_receipt(tx_hash)
                    print(f"{Fore.GREEN}Success: {address}{Fore.RESET}")
                    break
                except Exception as e:
                    retries += 1
                    print(f"{Fore.RED}Error (try {retries}/{max_retries}): {str(e)}{Fore.RESET}")
                    if retries < max_retries:
                        time.sleep(10)
                    else:
                        print(f"{Fore.RED}Failed after {max_retries} attempts: {address}{Fore.RESET}")
            time.sleep(2)
        except Exception as e:
            print(f"{Fore.RED}Error: {str(e)}{Fore.RESET}")

def main():
    f = Figlet(font='slant')
    print(f"{Fore.LIGHTCYAN_EX}{f.renderText('Yuurisandesu')}{Fore.RESET}")
    print(f"{Fore.MAGENTA}Welcome to Yuuri AIV Faucet Claim{Fore.RESET}")
    print(f"{Fore.GREEN}Ready to hack the world?{Fore.RESET}")
    print(f"{Fore.YELLOW}Current time: {datetime.now().strftime('%d-%m-%Y %H:%M:%S')}{Fore.RESET}")
    print()
    print("Menu:")
    print("1. Claim Faucet")
    print("2. Send Fee")
    print("3. Transfer Faucet")
    choice = input("Choose option (1/2/3): ").strip()

    if choice == '1':
        claim_faucet()
    elif choice == '2':
        send_fee()
    elif choice == '3':
        transfer_faucet()
    else:
        print(f"{Fore.RED}Invalid option{Fore.RESET}")

if __name__ == "__main__":
    main()
