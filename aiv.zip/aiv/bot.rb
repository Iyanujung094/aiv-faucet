require "json"
require "time"
require "base64"
require "securerandom"
require "faraday"
require "colorize"
require "artii"
require "dotenv/load"
require "eth"

ADDRESS_PENERIMA = ENV["ADDRESS_PENERIMA"]
JUMLAH_TX_FEE    = (ENV["JUMLAH_TX_FEE"] || "0.000006").to_f
PK_PENGIRIM      = ENV["PK_PENGIRIM"]

SUPABASE_URL     = "https://jpvvaetqdxhezxuuwpcw.supabase.co/functions/v1/faucet-claim"
SUPABASE_APIKEY  = ENV["SUPABASE_APIKEY"]
SUPABASE_JWT     = ENV["SUPABASE_JWT"]

RPC_URL  = "https://sepolia-rollup.arbitrum.io/rpc"
CHAIN_ID = 421_614
AIV_CONTRACT_ADDRESS = "0x78741720bf7ae1b9406421AeA2FC2Ce9F44d3858".freeze

def to_wei_eth(amount_eth)
  (amount_eth * (10**18)).to_i
end

def from_wei_eth(wei)
  wei.to_f / (10**18)
end

def hex_quantity(i)
  "0x" + i.to_i.to_s(16)
end

def left_pad_64(hex_noprefix)
  hex_noprefix.rjust(64, "0")
end

def valid_address?(addr)
  !!(addr =~ /\A0x[0-9a-fA-F]{40}\z/)
end

def load_wallets
  if File.exist?("wallets.json")
    JSON.parse(File.read("wallets.json"))
  else
    []
  end
end

def save_wallets(wallets)
  File.write("wallets.json", JSON.pretty_generate(wallets))
end

class EthClient
  def initialize(rpc_url)
    @rpc_url = rpc_url
    @http = Faraday.new(url: rpc_url) do |f|
      f.request :json
      f.response :raise_error rescue nil
      f.adapter Faraday.default_adapter
    end
  end

  def rpc(method, params = [])
    resp = @http.post do |req|
      req.headers["Content-Type"] = "application/json"
      req.body = { jsonrpc: "2.0", id: 1, method: method, params: params }.to_json
    end
    body = JSON.parse(resp.body)
    raise(body["error"] ? body["error"].inspect : "Unknown RPC error") if body["error"]
    body["result"]
  end

  def get_balance(address)
    rpc("eth_getBalance", [address, "latest"]).to_i(16)
  end

  def get_nonce(address)
    rpc("eth_getTransactionCount", [address, "pending"]).to_i(16)
  end

  def send_raw_transaction(raw_hex)
    rpc("eth_sendRawTransaction", [raw_hex])
  end

  def get_receipt(txid)
    rpc("eth_getTransactionReceipt", [txid])
  end

  def wait_for_receipt(txid, timeout: 180)
    start = Time.now
    loop do
      rcpt = get_receipt(txid)
      return rcpt if rcpt
      raise "Timeout waiting for receipt" if Time.now - start > timeout
      sleep 2
    end
  end

  def eth_call(to:, data:)
    rpc("eth_call", [{ "to" => to, "data" => data }, "latest"])
  end
end

def sign_and_send!(client:, key:, to:, value:, data:, gas_limit:, gas_price:)
  nonce = client.get_nonce(key.address)
  tx = Eth::Tx.new(
    to: to,
    value: value,
    data: (data || "0x"),
    gas_limit: gas_limit,
    gas_price: gas_price,
    nonce: nonce,
    chain_id: CHAIN_ID
  )
  tx.sign key
  raw = tx.hex.start_with?("0x") ? tx.hex : "0x#{tx.hex}"
  client.send_raw_transaction(raw)
end

def erc20_balance_of(client:, owner:)
  sig = "70a08231"
  addr = owner.downcase.sub(/^0x/, "")
  data = "0x#{sig}#{left_pad_64(addr)}"
  result = client.eth_call(to: AIV_CONTRACT_ADDRESS, data: data)
  result.to_i(16)
end

def erc20_transfer_data(to:, amount:)
  sig = "a9059cbb"
  to_no0x = to.downcase.sub(/^0x/, "")
  amt_hex = amount.to_i.to_s(16)
  "0x#{sig}#{left_pad_64(to_no0x)}#{left_pad_64(amt_hex)}"
end

def supabase_headers
  bearer = SUPABASE_JWT.to_s.start_with?("Bearer ") ? SUPABASE_JWT : "Bearer #{SUPABASE_JWT}"
  {
    "accept" => "*/*",
    "accept-encoding" => "gzip, deflate, br, zstd",
    "accept-language" => "ja,en-US;q=0.9,en;q=0.8",
    "apikey" => SUPABASE_APIKEY.to_s,
    "authorization" => bearer,
    "content-type" => "application/json",
    "origin" => "https://aivoraprotocol.xyz",
    "referer" => "https://aivoraprotocol.xyz/",
    "sec-ch-ua" => %Q("Not;A=Brand";v="99", "Microsoft Edge";v="139", "Chromium";v="139"),
    "sec-ch-ua-mobile" => "?0",
    "sec-ch-ua-platform" => %Q("Windows"),
    "sec-fetch-dest" => "empty",
    "sec-fetch-mode" => "cors",
    "sec-fetch-site" => "cross-site",
    "user-agent" => "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36 Edg/139.0.0.0",
    "x-client-info" => "supabase-js-web/2.56.1"
  }
end

def claim_faucet
  http = Faraday.new(url: SUPABASE_URL) do |f|
    f.request :json
    f.response :raise_error rescue nil
    f.adapter Faraday.default_adapter
  end

  puts "Mulai klaim faucet (gunakan kredensial sah di .env). Tekan CTRL+C untuk berhenti.".yellow
  loop do
    begin
      key = Eth::Key.new
      address = key.address
      priv_hex = key.private_hex
      priv_hex = "0x#{priv_hex}" unless priv_hex.start_with?("0x")

      payload = { walletAddress: address }
      puts "Sending request for address: #{address}".yellow
      resp = http.post do |req|
        req.headers = supabase_headers
        req.body = payload.to_json
      end

      if resp.status == 200
        wallets = load_wallets
        wallets << { "address" => address, "private_key" => priv_hex }
        save_wallets(wallets)
        puts "Success: Wallet saved: #{address}".green
      else
        puts "Failed: Status #{resp.status}: #{resp.body}".red
      end

      sleep 0.1
    rescue Interrupt
      puts "Stopped by user".yellow
      break
    rescue => e
      puts "Error: #{e.message}".red
      sleep 0.1
    end
  end
end

def send_fee
  if PK_PENGIRIM.to_s.empty?
    puts "PK_PENGIRIM not found in .env".red
    exit
  end

  transfer_amount = to_wei_eth(JUMLAH_TX_FEE)
  client = EthClient.new(RPC_URL)

  wallets = load_wallets
  if wallets.empty?
    puts "File wallets.json not found atau kosong".red
    exit
  end

  begin
    sender_key = Eth::Key.new(priv: PK_PENGIRIM.sub(/^0x/, ""))
    sender_address = sender_key.address
  rescue
    puts "Invalid private key".red
    exit
  end

  sender_balance = client.get_balance(sender_address)
  required_total = transfer_amount * wallets.length + to_wei_eth(0.001)
  if sender_balance < required_total
    need_eth = from_wei_eth(required_total)
    puts "Sender balance insufficient. Need at least #{need_eth} ETH".red
    exit
  end

  wallets.each_with_index do |w, idx|
    recipient = w["address"]
    puts "Processing transfer to: #{recipient} (#{idx + 1}/#{wallets.length})".yellow
    begin
      txid = sign_and_send!(
        client: client,
        key: sender_key,
        to: recipient,
        value: transfer_amount,
        data: "0x",
        gas_limit: 25_000,
        gas_price: 1_000_000_000
      )
      puts "Tx sent: #{txid}".green
      client.wait_for_receipt(txid)
      puts "Success: Transferred to #{recipient}".green
      sleep 2
    rescue => e
      puts "Error: #{e.message}".red
    end
  end
end

def transfer_faucet
  client = EthClient.new(RPC_URL)

  wallets = load_wallets
  if wallets.empty?
    puts "File wallets.json not found atau kosong".red
    exit
  end

  unless valid_address?(ADDRESS_PENERIMA.to_s)
    puts "Invalid destination address".red
    exit
  end
  destination = ADDRESS_PENERIMA

  wallets.each_with_index do |w, idx|
    address = w["address"]
    priv    = w["private_key"].to_s
    puts "Processing: #{address} (#{idx + 1}/#{wallets.length})".yellow

    begin
      eth_bal = client.get_balance(address)
      if eth_bal < to_wei_eth(0.000006)
        puts "ETH low (<0.000006), skipping: #{address}".yellow
        next
      end

      aiv_bal = erc20_balance_of(client: client, owner: address)
      if aiv_bal == 0
        puts "AIV 0, skipping: #{address}".yellow
        next
      end

      puts "AIV balance: #{from_wei_eth(aiv_bal)} - Sending to #{destination}".yellow

      retries = 0
      max_retries = 3
      begin
        key = Eth::Key.new(priv: priv.sub(/^0x/, ""))

        data = erc20_transfer_data(to: destination, amount: aiv_bal)
        txid = sign_and_send!(
          client: client,
          key: key,
          to: AIV_CONTRACT_ADDRESS,
          value: 0,
          data: data,
          gas_limit: 60_000,
          gas_price: 100_000_000
        )
        puts "Tx sent: #{txid}".green
        client.wait_for_receipt(txid)
        puts "Success: #{address}".green
      rescue => e
        retries += 1
        puts "Error (try #{retries}/#{max_retries}): #{e.message}".red
        if retries < max_retries
          sleep 10
          retry
        else
          puts "Failed after #{max_retries} attempts: #{address}".red
        end
      end

      sleep 2
    rescue => e
      puts "Error: #{e.message}".red
    end
  end
end

def banner
  Artii::Base.new(font: "slant").asciify("Yuurisandesu")
end

def main
  puts banner.light_cyan
  puts "Welcome to Yuuri AIV Faucet Claim".magenta
  puts "Ready to hack the world?".green
  puts "Current time: #{Time.now.strftime('%d-%m-%Y %H:%M:%S')}".yellow
  puts
  puts "Menu:"
  puts "1. Claim Faucet"
  puts "2. Send Fee"
  puts "3. Transfer Faucet"
  print "Choose option (1/2/3): "

  choice = STDIN.gets&.strip
  case choice
  when "1"
    claim_faucet
  when "2"
    send_fee
  when "3"
    transfer_faucet
  else
    puts "Invalid option".red
  end
end

if __FILE__ == $0
  main
end
